
<?php
$db = new mysqli("localhost", "root", "", "guestdb");

if($db->connect_errno){
	die("Connection Failed : ". $db->connect_error);
}

$tempGuest = $tempAddress = $tempEmail = $tempPhone = $tempRoom = $tempArival = $tempDepa = null;

if(isset($_POST["add"])){
	$guestName = $_POST["guestName"];
	$address = $_POST["address"];
	$email = $_POST["email"];
	$phoneNo = $_POST["phoneNo"];
	$room = $_POST["room"];
	$arrival = $_POST["arrival"];
	$departure = $_POST["departure"];
	
	$query = "INSERT INTO guests VALUES('$guestName','$address','$email','$phoneNo','$room','$arrival','$departure')";
	if($db->query($query)){
		echo "Success";
	}else{
		echo "Failed";
	}
	
}else if(isset($_POST["search"])){
	$email = $_POST["email"];
	$room = $_POST["room"];
	
	$query = "SELECT * FROM guests WHERE email = '$email' AND room_type = '$room'";
	$result = $db->query($query);
	if($result){
		while($row = $result->fetch_assoc()){
			$tempGuest = $row["guestname"];
			$tempAddress = $row["address"];
			$tempEmail = $row["email"];
			$tempPhone = $row["phone_no"];
			$tempRoom = $row["room_type"];
			$tempArival = $row["arri_date"];
			$tempDepa = $row["dept_date"];
			break;
		}
	}else{
		echo "Failed";
	}
	
}else if(isset($_POST["update"])){
	$guestName = $_POST["guestName"];
	$address = $_POST["address"];
	$email = $_POST["email"];
	$phoneNo = $_POST["phoneNo"];
	$room = $_POST["room"];
	$arrival = $_POST["arrival"];
	$departure = $_POST["departure"];
	
	$query = "UPDATE guests SET guestname = '$guestName', address = '$address', phone_no = '$phoneNo', arri_date = '$arrival', dept_date = '$departure' WHERE email ='$email' AND room_type='$room'";
	if($db->query($query)){
		echo "Success";
	}else{
		echo "Failed";
	}
	
}else if(isset($_POST["delete"])){
	$email = $_POST["email"];
	$room = $_POST["room"];
	
	$query = "DELETE FROM guests WHERE email = '$email' AND room_type = '$room'";
	$result = $db->query($query);
	if($result){
		echo "Success";
	}else{
		echo "Failed";
	}
}
?>
<!DOCTYPE html>
<html>

	<head>
		<style>
			.body
			{
				border: 2px solid black;
				padding: 10px;
				width: 350px;
				padding-top: 0px;
			}
		
			.add
			{
				margin-left: 30px;
				margin-right: 40px;
			}
		</style>
	</head>

	<body class="body">
	
		<form method="post" action="" class="form">
		
			<h3>Hotel Registration Form</h3>
			
			<table>
				<tr>
					<td><label name="guestName">Guest Name : </label></td>
					<td><input type="text" name="guestName"value="<?php echo $tempGuest?>" id="guestName"/></td>
				</tr>
				
				<tr>
					<td><label name="address">Address : </label></td>
					<td><input type="text" name="address" value="<?php echo $tempAddress?>" id="address"/></td>
				</tr>
				
				<tr>
					<td><label name="email">E-mail : </label></td>
					<td><input type="text" name="email" value="<?php echo $tempEmail;?>" /></td>
				</tr>
				
				<tr>
					<td><label name="phoneNo">Phone No : </label></td>
					<td><input type="text" name="phoneNo" value="<?php echo $tempPhone;?>"/></td>
				</tr>
				
				<tr>
					<td><label name="roomType">Room Type : </label></td>
					<td><select name="room" value="<?php echo $tempRoom;?>" >
							<option value="">--Please select a room type--</option>
							<option value="single">Single Room</option>
							<option value="double">Double Room</option>
							<option value="triple">Triple</option>
							<option value="quard">Guard</option>
							<option value="queen">Queen</option>
							<option value="king">King</option>
							<option value="twin">Twin</option>
						</select></td>
				</tr>
				
				<tr>
					<td><label name="arrival">Arrival Date : </label></td>
					<td><input type="date" name="arrival" value="<?php echo $tempArival;?>"/></td>
				</tr>
				
				<tr>
					<td><label name="departure">Departure Date : </label></td>
					<td><input type="date" name="departure" value="<?php echo $tempDepa;?>"/></td>
				</tr>
			</table>
			
			<input type="submit" name="add" id="add" value="Add" class="add"/>
			<input type="reset" name="clear" id="clear" value="Clear"/>
			<input type="submit" name="search" id="search" value="Search"/>
			<input type="submit" name="update" id="update" value="Update"/>
			<input type="submit" name="delete" id="delete" value="Delete"/>
		
		</form>
	
	</body>

</html>
<?php 
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "guestDB";
	
	$conn = new mysqli($servername,$username,$password,$dbname);
	
	if($conn->connect_error)
		die("Connection failed " . $conn->connect_error);
	
	$sql1 = "INSERT INTO guests VALUES
			(
				'Saro',
				'10, Main Road, Batticaloa',
				'saro@gmail.com',
				'0779998888',
				'Single',
				'2022-09-21 10:02:00',
				'2022-09-23'
			)";
			
	if($conn->query($sql1) == TRUE)
		echo "Value 1 is added successfully";
	else
		echo "Error " . $conn->error;
	
	$sql2 = "INSERT INTO guests VALUES
			(
				'Kiroo',
				'1B, Vavuniya',
				'kiroo@gmail.com',
				'0754265897',
				'Queen',
				'2023-03-11 12:02:00',
				'2023-03-20'
			)";
			
	if($conn->query($sql2) == TRUE)
		echo "Value 2 is added successfully";
	else
		echo "Error " . $conn->error;
	
	$sql3 = "INSERT INTO guests VALUES
			(
				'Saji',
				'Dehiwala, Colombo',
				'saji@gmail.com',
				'0751643298',
				'Double',
				'2021-01-25 11:02:00',
				'2021-02-02'
			)";
			
	if($conn->query($sql3) == TRUE)
		echo "Value 3 is added successfully";
	else
		echo "Error " . $conn->error;
	
	mysqli_close($conn);
?>
<html>
  <head>
      <title>CONVERT ROMAN TO DECIMAL</title>
  </head>
  <body>
     <form method="post">
	   <label>Enter the  Number: </label>
	   <input type="text" name="num" id="roman">
	   <input type="submit" value="convert">
	 </form>
     
<?php

function decimalToBinary($decimalNumber) {
   $binaryNumber = "";

   while ($decimalNumber > 0) {
       // Get the remainder when divided by 2
       $remainder = $decimalNumber % 2;

       // Append the remainder (0 or 1) to the binary string
       $binaryNumber = $remainder . $binaryNumber;

       // Divide the decimal number by 2 for the next iteration
       $decimalNumber = (int)($decimalNumber / 2);
   }

   return $binaryNumber;
}

// Get decimal input from the user

 
    if($_SERVER["REQUEST_METHOD"]=="POST"){
			$decimal  =$_POST["num"];

// Convert decimal to binary
$binary = decimalToBinary($decimal);

// Display the result
	echo "The binary equivalent of $decimal is $binary\n";}

?>

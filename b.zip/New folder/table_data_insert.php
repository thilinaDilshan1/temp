<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guestDB";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



    $sql = "INSERT INTO guests (guestname,address,email,phone_no,room_type,arri_date,dept_date) VALUES ('shan','colombo','as@gmail.com','0775428965','double','2023-11-16','2023-11-22'),
	                         ('shan1','colombo','as1@gmail.com','0775428965','double','2023-11-16','2023-11-22'),
	                           ('kiru','colombo','as2@gmail.com','0775428965','double','2023-11-16','2023-11-22'),
							   ('jathu','colombo','as3@gmail.com','0775428965','double','2023-11-16','2023-11-22'),
							   ('riya','colombo','as4@gmail.com','0775428965','double','2023-11-16','2023-11-22')";
    if ($conn->query($sql) !== TRUE) {
        echo "Error inserting data: " . $conn->error;
        break; 
    }


echo "Records inserted successfully";

$conn->close();
?>
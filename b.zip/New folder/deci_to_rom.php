<html>
<head></head>
<body>
   <form method="post">
	   <label>Enter the  Number: </label>
	   <input type="text" name="num" id="num">
	   <input type="submit" value="convert">
	 </form>
<?php
 

function decimalToRoman($number) {
    $romanSymbols = array(
        'M' => 1000,
        'CM' => 900,
        'D' => 500,
        'CD' => 400,
        'C' => 100,
        'XC' => 90,
        'L' => 50,
        'XL' => 40,
        'X' => 10,
        'IX' => 9,
        'V' => 5,
        'IV' => 4,
        'I' => 1
    );

    $romanNumeral = '';

    foreach ($romanSymbols as $symbol => $value) {
        while ($number >= $value) {
            $romanNumeral .= $symbol;
            $number -= $value;
        }
    }

    return $romanNumeral;
}

// Example usage:
   if($_SERVER["REQUEST_METHOD"]=="POST"){
			$decimal=$_POST["num"];
			
$roman = decimalToRoman($decimal);
echo "$decimal in Roman numerals is $roman";
   }
?>
</body>
</html>
<html>
  <head>
      <title>CONVERT ROMAN TO DECIMAL</title>
  </head>
  <body>
     <form method="post">
	   <label>Enter the Roman Number: </label>
	   <input type="text" name="roman" id="roman">
	   <input type="submit" value="convert">
	 </form>
     <?php
	    if($_SERVER["REQUEST_METHOD"]=="POST"){
			$rom_num =$_POST["roman"];
			

function romanToDecimalAlgorithm($roman) {
    $romanNumerals = [
        'M' => 1000,
        'D' => 500,
        'C' => 100,
        'L' => 50,
        'X' => 10,
        'V' => 5,
        'I' => 1
    ];

    $decimal = $romanNumerals[$roman[0]];
    $length = strlen($roman);
    $i = 1;

    while ($i < $length) {
        $currentValue = $romanNumerals[$roman[$i]];
        $prevValue = $romanNumerals[$roman[$i - 1]];

        $decimal += $currentValue;

        if ($currentValue > $prevValue) {
            $decimal -= 2 * $prevValue;
        }

        $i++;
    }

    return $decimal;
}


		}
		$RESULT=romanToDecimalAlgorithm($rom_num);
		echo $RESULT;
	      
	 ?>
  </body>
  
</html>
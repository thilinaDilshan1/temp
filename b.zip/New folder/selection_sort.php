<?php

function selectionSort($array) {
    for ($i = 0; $i < count($array) - 1; $i++) {
        $minIndex = $i;
        for ($j = $i + 1; $j < count($array); $j++) {
            if ($array[$j] < $array[$minIndex]) {
                $minIndex = $j;
            }
        }

        // Swap the elements at $i and $minIndex
        if ($minIndex !== $i) {
            $temp = $array[$i];
            $array[$i] = $array[$minIndex];
            $array[$minIndex] = $temp;
        }
    }

    return $array;
}

// Example usage:
$myArray = array(5, 3, 8, 1, 9, 2);
echo "Original array: " . implode(", ", $myArray) . "\n";

$sortedArray = selectionSort($myArray);
echo "Sorted array: " . implode(", ", $sortedArray) . "\n";

?>


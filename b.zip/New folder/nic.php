<html>
 <head>
 </head>
 <body>
    <form method="post">
	   Enter the NIC No.
	   <input type="text" name="nic" >
	   <input type="submit" value="calculate">
	</form>
	<?php
	  $nic=$_POST["nic"];
	  echo "NIC No: ".$nic."<br>";
      if(strlen($nic)==10){
	     $year=substr($nic,0,2);
		 $num=substr($nic,2,3);
		 if($num>500){
		   echo "Gender : Female <br>";
		   $month=$num-500;
		 }
		 else{
		   echo  "Gender : Male <br>";
		   $month=$num;
		 }
		 echo "Year: 19".$year."<br>";
	  }
	  else if(strlen($nic)==12){
		 $year=substr($nic,0,4);
		 $num=substr($nic,4,3);
		 if($num>500){
		   echo "Gender : Female <br>";
		   $month=$num-500;
		 }
		 else{
		   echo  "Gender : Male <br>";
		   $month=$num;
		 }
		 echo "Year: ".$year."<br>"; 
	  }
	  else{
		  echo "invalid number";
	  }
	  
		 if($year%4!=0){
		    if($month<32){
			  echo "Month: January <br>";
			  $day=$month;
			  echo "Day : ".$day."<br>";
			}
		    else if($month<61){
			  echo "Month: february <br>";
			  $day=$month-31;
			  echo "Day : ".$day."<br>";
			}
			else if($month<92){
			  echo "Month: March <br>";
			  $day=$month-60;
			  echo "Day : ".$day."<br>";
			}else if($month<122){
			  echo "Month: April <br>";
			  $day=$month-91;
			  echo "Day : ".$day."<br>";
			}
			else if($month<153){
			  echo "Month: May <br>";
			  $day=$month-121;
			  echo "Day : ".$day."<br>";
			}
			else if($month<183){
			  echo "Month: June <br>";
			  $day=$month-152;
			  echo "Day : ".$day."<br>";
			}
			else if($month<214){
			  echo "Month: July <br>";
			  $day=$month-182;
			  echo "Day : ".$day."<br>";
			}
			else if($month<245){
			  echo "Month: August <br>";
			  $day=$month-213;
			  echo "Day : ".$day."<br>";
			}
			else if($month<275){
			  echo "Month: September <br>";
			  $day=$month-244;
			  echo "Day : ".$day."<br>";
			}
			else if($month<306){
			  echo "Month: October <br>";
			  $day=$month-274;
			  echo "Day : ".$day."<br>";
			}
			else if($month<336){
			  echo "Month: November <br>";
			  $day=$month-305;
			  echo "Day : ".$day."<br>";
			}
			else {
			  echo "Month: December <br>";
			  $day=$month-335;
			  echo "Day : ".$day."<br>";
			}
		 }
		  if($year%4==0){
		    if($month<32){
			  echo "Month: January <br>";
			  $day=$month;
			  echo "Day : ".$day."<br>";
			}
		    else if($month<60){
			  echo "Month: february <br>";
			  $day=$month-31;
			  echo "Day : ".$day."<br>";
			}
			else if($month<91){
			  echo "Month: March <br>";
			  $day=$month-59;
			  echo "Day : ".$day."<br>";
			}else if($month<121){
			  echo "Month: April <br>";
			  $day=$month-90;
			  echo "Day : ".$day."<br>";
			}
			else if($month<152){
			  echo "Month: May <br>";
			  $day=$month-120;
			  echo "Day : ".$day."<br>";
			}
			else if($month<184){
			  echo "Month: June <br>";
			  $day=$month-151;
			  echo "Day : ".$day."<br>";
			}
			else if($month<213){
			  echo "Month: July <br>";
			  $day=$month-183;
			  echo "Day : ".$day."<br>";
			}
			else if($month<244){
			  echo "Month: August <br>";
			  $day=$month-212;
			  echo "Day : ".$day."<br>";
			}
			else if($month<274){
			  echo "Month: September <br>";
			  $day=$month-243;
			  echo "Day : ".$day."<br>";
			}
			else if($month<305){
			  echo "Month: October <br>";
			  $day=$month-273;
			  echo "Day : ".$day."<br>";
			}
			else if($month<335){
			  echo "Month: November <br>";
			  $day=$month-304;
			  echo "Day : ".$day."<br>";
			}
			else {
			  echo "Month: December <br>";
			  $day=$month-334;
			  echo "Day : ".$day."<br>";
			}
		 }
	  

	  
	 ?>
	  
 </body>
</html>
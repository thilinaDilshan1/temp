<DOCTYPE html>
<html>
  <head>
     <title>Dashboard</title>
	 <style>
    </style>
  </head>
  <body>
    <h1>WELCOME TO OUR PAGE</h1>
	
	<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

echo "Welcome, " . $_SESSION['username'] . "!"."<br>";

?>
  <a href="logout.php">Logout</a><br>
  </body>
</html>
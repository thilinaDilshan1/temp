<DOCTYPE html>
<html>
  <head>
     <title>registration</title>
	 <style>
	 body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display:flex ;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
	 form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        h1 {
            text-align: center;
            color: #333;
        }
		

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            background-color: blue;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        button:hover {
            background-color: lightblue;
			color:black;
        }
    </style>
  </head>
  <body>
    <h1>Registration Form</h1>
	<form method="post" action="registration.php">
	  <label for="studentid">StudentId :</label>
	  <input type="text" name="studentid" id="studentid" required><br>
	  <label for="username"> UserName :</label>
	  <input type="text" name="username" id="username" required><br>
	  <label for="password">Password :</label>
	  <input type="password" name="password" id="password" required><br>
	  <button type="submit">SignUp</button>
	  <a href="login.php">Login</a>
	</form>
	<?php
    require_once('dbconnection.php');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$StudentId = $_POST['studentid'];
        $UserName = $_POST['username'];
        $password = $_POST['password'];

 
       $sql = "INSERT INTO registration  (StudentId,UserName, Password) VALUES ('$StudentId','$UserName', '$password')";
       if ($conn->query($sql) === TRUE) {
          echo "Registration successful!";
		 
       } else {
           echo "Error: " . $sql . "<br>" . $conn->error;
       }
    }

    $conn->close();
   ?>
	
  </body>
</html>
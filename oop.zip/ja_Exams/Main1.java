// Publication class with title and price
class Publication {
    private String title;
    private double price;

    // Constructor
    public Publication(String title, double price) {
        this.title = title;
        this.price = price;
    }

    // Method to get data
    public void getData() {
        System.out.println("Title: " + title);
        System.out.println("Price: $" + price);
    }

    // Method to print
    public void print() {
        System.out.println("Publication Details:");
        getData();
    }
}

// Interface Book with accession number
interface Book {
    int accessionNumber = 0; // Interface fields are implicitly public, static, and final

    // Methods
    void getData();

    void print();
}

// Interface Magazine with volume number
interface Magazine {
    int volumeNumber = 0; // Interface fields are implicitly public, static, and final

    // Methods
    void getData();

    void print();
}

// Journal class inheriting from Publication
class Journal extends Publication {
    private String journalName;

    // Constructor
    public Journal(String title, double price, String journalName) {
        super(title, price);
        this.journalName = journalName;
    }

    // Override print method to ensure interface methods invoke base class methods
    @Override
    public void print() {
        System.out.println("Journal Details:");
        super.print();
        System.out.println("Journal Name: " + journalName);
    }
}

public class Main1 {
    public static void main(String[] args) {
        // Creating five objects for the Journal class
        Journal journal1 = new Journal("Journal 1", 15.99, "Science Journal");
        Journal journal2 = new Journal("Journal 2", 19.99, "History Journal");
        Journal journal3 = new Journal("Journal 3", 12.99, "Art Journal");
        Journal journal4 = new Journal("Journal 4", 17.99, "Technology Journal");
        Journal journal5 = new Journal("Journal 5", 14.99, "Literature Journal");

        // Invoking getData() and print() functions for each object
        journal1.print();
        System.out.println("--------------------");
        journal2.print();
        System.out.println("--------------------");
        journal3.print();
        System.out.println("--------------------");
        journal4.print();
        System.out.println("--------------------");
        journal5.print();
    }
}
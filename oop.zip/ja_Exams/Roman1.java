import java.util.HashMap;
public class Roman1 {

    // HashMap for quick Roman numeral to integer conversion
    private static final HashMap<Character, Integer> romanToIntegerMap = new HashMap<>();

    static {
        romanToIntegerMap.put('I', 1);
        romanToIntegerMap.put('V', 5);
        romanToIntegerMap.put('X', 10);
        romanToIntegerMap.put('L', 50);
        romanToIntegerMap.put('C', 100);
        romanToIntegerMap.put('D', 500);
        romanToIntegerMap.put('M', 1000);
    }

    /**
     * Converts a Roman numeral string to its equivalent integer value.
     *
     * @param romanNumeral The Roman numeral string
     * @return The integer value of the Roman numeral
     */
    public static int romanToInteger(String romanNumeral) {
        int result = 0;
        int previousValue = 0;

        for (int i = romanNumeral.length() - 1; i >= 0; i--) {
            int currentValue = romanToIntegerMap.get(romanNumeral.charAt(i));

            if (currentValue >= previousValue) {
                result += currentValue;
            } else {
                result -= currentValue;
            }

            previousValue = currentValue;
        }

        return result;
    }

    /**
     * Converts an integer to its equivalent Roman numeral string.
     *
     * @param number The integer value
     * @return The Roman numeral string
     */
    public static String integerToRoman(int number) {
        StringBuilder roman = new StringBuilder();
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

        for (int i = 0; i < values.length; i++) {
            while (number >= values[i]) {
                number -= values[i];
                roman.append(symbols[i]);
            }
        }

        return roman.toString();
    }

    public static void main(String[] args) {
        String romanNumeral = "MCMXCIV";  // Example Roman numeral
        int integerValue = romanToInteger(romanNumeral);
        System.out.println("Roman numeral " + romanNumeral + " is equal to " + integerValue);

        int number = 2024;  // Example integer
        String romanEquivalent = integerToRoman(number);
        System.out.println("Integer " + number + " is equal to " + romanEquivalent);
    }
}

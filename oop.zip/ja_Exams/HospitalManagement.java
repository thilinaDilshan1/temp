import java.util.Date;

// Person class as a base class for Doctor, Nurse, and Patient
class Person {
    private String name;
    private String gender;
    private Date joinDate;

    public Person(String name, String gender, Date joinDate) {
        this.name = name;
        this.gender = gender;
        this.joinDate = joinDate;
    }
	public String getName(){
		return name;
	
    }

// G}etters and setters for common fields
    // ...

    public void work(int hours) {
        // Common work logic for all team members
        if (hours <= 12) {
            System.out.println(name + " worked for " + hours + " hours.");
        } else {
            System.out.println(name + " exceeded the maximum working time.");
        }
    }
}

// Department class
class Department {
    private String name;
    private Person[] staff;
    private int staffCount;

    public Department(String name, int maxStaffSize) {
        this.name = name;
        this.staff = new Person[maxStaffSize];
        this.staffCount = 0;
    }

    public void addTeamMember(Person teamMember) {
        if (staffCount < staff.length) {
            staff[staffCount++] = teamMember;
        } else {
            System.out.println("Cannot add more team members. Department is full.");
        }
    }

    public void removeTeamMember(Person teamMember) {
        for (int i = 0; i < staffCount; i++) {
            if (staff[i].equals(teamMember)) {
                // Shift elements to fill the gap
                for (int j = i; j < staffCount - 1; j++) {
                    staff[j] = staff[j + 1];
                }
                staffCount--;
                break;
            }
        }
    }

    // Getters and setters
    // ...
}

// Doctor class as a base class for Intern, SeniorDoctor, and Surgeon
class Doctor extends Person {
    private String specialty;
    private Patient[] patients;
    private int patientCount;

    public Doctor(String name, String gender, Date joinDate, String specialty, int maxPatients) {
        super(name, gender, joinDate);
        this.specialty = specialty;
        this.patients = new Patient[maxPatients];
        this.patientCount = 0;
    }

    // Additional methods for doctors
    public void checkReport(Patient patient) {
        // Logic to check the report
        System.out.println("Doctor " + getName() + " checked the report of " + patient.getName());
    }

    public void treatPatient(Patient patient) {
        // Default implementation, can be overridden by subclasses
        System.out.println("Doctor " + getName() + " is treating patient " + patient.getName());
    }

    // Getters and setters for doctor-specific fields
    // ...

    // Additional logic for doctors
    // ...
}

// Intern class
class Intern extends Doctor {
    private SeniorDoctor supervisor;

    public Intern(String name, String gender, Date joinDate, String specialty, SeniorDoctor supervisor) {
        super(name, gender, joinDate, specialty, 0); // Interns have no patients initially
        this.supervisor = supervisor;
    }

    @Override
    public void treatPatient(Patient patient) {
        // Specific implementation for interns
        System.out.println("Intern " + getName() + " is treating patient " + patient.getName());
    }

    // Getters and setters for intern-specific fields
    // ...
}

// SeniorDoctor class
class SeniorDoctor extends Doctor {

    public SeniorDoctor(String name, String gender, Date joinDate, String specialty, int maxPatients) {
        super(name, gender, joinDate, specialty, maxPatients);
    }

    @Override
    public void treatPatient(Patient patient) {
        // Specific implementation for SeniorDoctor
        System.out.println("Senior Doctor " + getName() + " is treating patient " + patient.getName());
    }

    // Additional methods specific to SeniorDoctor
    // ...

}

// Surgeon class
class Surgeon extends Doctor {

    public Surgeon(String name, String gender, Date joinDate, String specialty, int maxPatients) {
        super(name, gender, joinDate, specialty, maxPatients);
    }

    @Override
    public void treatPatient(Patient patient) {
        // Specific implementation for Surgeon
        System.out.println("Surgeon " + getName() + " is performing surgery on patient " + patient.getName());
    }

    // Additional methods specific to Surgeon
    // ...

}

// Nurse class
class Nurse extends Person {

    public Nurse(String name, String gender, Date joinDate) {
        super(name, gender, joinDate);
    }

    // Additional methods specific to Nurse
    // ...

}

// Patient class
class Patient extends Person {
    private String diagnosis;
    private Doctor treatingDoctor;
    private int stayDuration;

    public Patient(String name, String gender, Date joinDate, String diagnosis, Doctor treatingDoctor, int stayDuration) {
        super(name, gender, joinDate);
        this.diagnosis = diagnosis;
        this.treatingDoctor = treatingDoctor;
        this.stayDuration = stayDuration;
    }

    // Getters and setters for patient-specific fields
    // ...

    public void getTreatment() {
        treatingDoctor.treatPatient(this);
    }

    // Additional logic for patients
    // ...
}
class Hospital {
    private String name;
    private String address;
    public Patient[] patients;
    private Department[] departments;
    private int patientCount;
    private int departmentCount;

    public Hospital(String name, String address, int maxPatients, int maxDepartments) {
        this.name = name;
        this.address = address;
        this.patients = new Patient[maxPatients];
        this.departments = new Department[maxDepartments];
        this.patientCount = 0;
        this.departmentCount = 0;
    }

    public void addPatient(Patient patient) {
        if (patientCount < patients.length) {
            patients[patientCount++] = patient;
        } else {
            System.out.println("Cannot add more patients. Hospital is full.");
        }
    }

    public void removePatient(Patient patient) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].equals(patient)) {
                // Shift elements to fill the gap
                for (int j = i; j < patientCount - 1; j++) {
                    patients[j] = patients[j + 1];
                }
                patientCount--;
                break;
            }
        }
    }

    public void addDepartment(Department department) {
        if (departmentCount < departments.length) {
            departments[departmentCount++] = department;
        } else {
            System.out.println("Cannot add more departments. Hospital is full.");
        }
    }

    public void removeDepartment(Department department) {
        for (int i = 0; i < departmentCount; i++) {
            if (departments[i].equals(department)) {
                // Shift elements to fill the gap
                for (int j = i; j < departmentCount - 1; j++) {
                    departments[j] = departments[j + 1];
                }
                departmentCount--;
                break;
            }
        }
    }

    // Getters and setters for hospital-specific fields
    // ...
}


public class HospitalManagement {

    public static void main(String[] args) {
        // Create a hospital
        Hospital hospital = new Hospital("Sample Hospital", "123 Main Street", 100, 10);

        // Create doctors
        SeniorDoctor seniorDoctor = new SeniorDoctor("Dr. Smith", "Male", new Date(), "Cardiology", 5);
        Intern intern = new Intern("Dr. Johnson", "Female", new Date(), "Pediatrics", seniorDoctor);
        Surgeon surgeon = new Surgeon("Dr. Anderson", "Male", new Date(), "Orthopedics", 3);

        // Add doctors to the hospital
        hospital.addDepartment(new Department("Cardiology", 5));
        hospital.addDepartment(new Department("Pediatrics", 5));
        hospital.addDepartment(new Department("Orthopedics", 3));

        hospital.addPatient(new Patient("John Doe", "Male", new Date(), "Fever", seniorDoctor, 5));
        hospital.addPatient(new Patient("Jane Doe", "Female", new Date(), "Fracture", surgeon, 3));

        // Add nurses
        Nurse nurse1 = new Nurse("Nurse Smith", "Female", new Date());
        Nurse nurse2 = new Nurse("Nurse Johnson", "Male", new Date());

        // Add nurses to the hospital
        hospital.addDepartment(new Department("Nursing", 2));

        // Demonstrate basic functionality
        seniorDoctor.checkReport(hospital.patients[0]);
        intern.treatPatient(hospital.patients[1]);
        surgeon.treatPatient(hospital.patients[1]);

        // Demonstrate treating patients
        hospital.patients[0].getTreatment();
        hospital.patients[1].getTreatment();
    }
}
import java.util.Scanner;

class Book {
    private String author;
    private String title;
    private double price;
    private String publisher;
    private int stockPosition;

    public Book(String author, String title, double price, String publisher, int stockPosition) {
        this.author = author;
        this.title = title;
        this.price = price;
        this.publisher = publisher;
        this.stockPosition = stockPosition;
    }

    public void displayDetails() {
        System.out.println("Book Details:");
        System.out.println("Author: " + author);
        System.out.println("Title: " + title);
        System.out.println("Price: $" + price);
        System.out.println("Publisher: " + publisher);
        System.out.println("Stock Position: " + stockPosition);
    }

    public boolean checkAvailability(int requestedCopies) {
        if (requestedCopies <= stockPosition) {
            double totalCost = requestedCopies * price;
            System.out.println("Books are available. Total Cost: $" + totalCost);
			stockPosition-=requestedCopies;
			System.out.println("Stock position updated. Remaining stock: " + stockPosition);
            return true;
        } else {
            System.out.println("Required copies not in stock.");
            return false;
        }
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
    public int getStockPosition() {
        return stockPosition;
    }
}

public class BookShop {
    public static void main(String[] args) {
        // Create an array of books
        Book[] books = new Book[100];

        // Initialize some sample books
        books[0] = new Book("Author1", "Title1", 20.0, "Publisher1", 10);
        books[1] = new Book("Author2", "Title2", 15.0, "Publisher2", 5);
        // Add more books as needed

        Scanner scanner = new Scanner(System.in);
		
      
        System.out.print("Enter the title of the book: ");
        String titleInput = scanner.nextLine();

        System.out.print("Enter the author of the book: ");
        String authorInput = scanner.nextLine();
      
        // Search for the book in the array
        boolean bookFound = false;
        for (Book book : books) {
            if (book != null && book.getTitle().equals(titleInput) && book.getAuthor().equals(authorInput)) {
                book.displayDetails();

                System.out.print("Enter the number of copies required: ");
                int requestedCopies = scanner.nextInt();

                book.checkAvailability(requestedCopies);
                System.out.println("Updated Stock Position: " + book.getStockPosition());
                bookFound = true;
                break; // Stop searching once the book is found
            }
			
        }

        if (!bookFound) {
            System.out.println("Book not found in the inventory.");
        }

        scanner.close();
    }
}